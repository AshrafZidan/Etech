import { MyApp } from './../../app/app.component';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the CartPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cart',
  templateUrl: 'cart.html',
})
export class CartPage {
  empty = false;

  constructor(public navCtrl: NavController, public navParams: NavParams , private app:MyApp) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CartPage');
  }

  back(){
    this.app.openPage('HomePage');
  }



  openPage(namePage){
    this.app.openPage(namePage);
  }

}
