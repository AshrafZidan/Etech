import { MyApp } from './../../app/app.component';
import { AccordionComponent } from './../../components/accordion/accordion';
import { Http } from '@angular/http';
import { Component, ViewChild, Input, Renderer } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
AccordionComponent

/**
 * Generated class for the FilterPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-filter',
  templateUrl: 'filter.html',
})
export class FilterPage {
  accordionExapanded = false;
  @ViewChild("cc") cardContent: any;
 @Input('title') title: string;

  icon: string = "arrow-forward";

  information: any[];


  constructor(public navCtrl: NavController, public navParams: NavParams ,private http:Http , public renderer: Renderer , private app:MyApp) {


  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FilterPage');
  }



  toggleAccordion() {
    if (this.accordionExapanded) {
      this.renderer.setElementStyle(this.cardContent.nativeElement, "max-height", "0px");
      this.renderer.setElementStyle(this.cardContent.nativeElement, "padding", "0px 16px");

    } else {
      this.renderer.setElementStyle(this.cardContent.nativeElement, "max-height", "500px");
      this.renderer.setElementStyle(this.cardContent.nativeElement, "padding", "13px 16px");

    }

    this.accordionExapanded = !this.accordionExapanded;
    this.icon = this.icon == "arrow-forward" ? "arrow-down" : "arrow-forward";

  }


  back(){
    this.app.openPage('HomePage');
  }
}
